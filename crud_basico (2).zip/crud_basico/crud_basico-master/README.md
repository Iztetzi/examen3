# CRUD sencillo en PHP y MySQL
<img src="CRUD%20sencillo%20en%20PHP%20y%20MySQL.png">
Se comparte el código libremente y para descargar la base de datos puedes acceder al siguiente enlace:
https://www.configuroweb.com/46-aplicaciones-gratuitas-en-php-python-y-javascript/#crud-sencillo
