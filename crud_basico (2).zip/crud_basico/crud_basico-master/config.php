<?php
$mysqli = new mysqli('localhost', 'root', '', 'restaurante_italian');
?>