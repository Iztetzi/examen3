<?php
include("config.php");
include("session.php");

$tipodepizza = $_POST['tipodepizza'];
$ingredientes = $_POST['ingredientes'];
$tamaño = $_POST['tamaño'];
$precio = $_POST['precio'];


$sql = "INSERT INTO menudepizzas (tipodepizza, ingredientes, tamaño, precio) 
VALUES('$tipodepizza', '$ingredientes', '$tamaño', '$precio')";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Nuevo usuario agregado");';
	echo 'window.location="index.php";';
	echo '</script>';
	
} else {
	echo '<script language="javascript">';
	echo 'alert("Usuario duplicado!");';
	echo 'window.location="registration.php";';
	echo '</script>';
}
?>