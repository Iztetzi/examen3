<?php
include("config.php");
include("session.php");

$Codigoproducto = $_POST['Codigoproducto'];
$tipodepizza = $_POST['tipodepizza'];
$ingredientes = $_POST['ingredientes'];
$tamaño = $_POST['tamaño'];
$precio = $_POST['precio'];

$sql = "UPDATE menudepizzas SET Codigoproducto='$'Codigoproducto', tipodepizza='$tipodepizza', ingredientes='$ingredientes', tamaño='$tamaño', precio='$precio', 
WHERE menudepizzas ='$Codigoproducto'";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Registro actualizado exitósamente");';
	echo 'window.location="users.php";';
	echo '</script>';
	
} else {
	echo '<script language="javascript">';
	echo 'alert("Error en proceso de actualización de registro!");';
	echo 'window.location="users.php";';
	echo '</script>';
}
?>